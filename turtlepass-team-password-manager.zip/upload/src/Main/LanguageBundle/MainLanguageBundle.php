<?php

namespace Main\LanguageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MainLanguageBundle extends Bundle
{
}
