<?php

namespace Main\LanguageBundle\Entity;

use Doctrine\ORM\EntityRepository;

class LanguageTranslationRepository extends EntityRepository
{
}
