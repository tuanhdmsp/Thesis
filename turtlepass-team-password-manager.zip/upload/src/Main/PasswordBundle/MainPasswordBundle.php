<?php

namespace Main\PasswordBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MainPasswordBundle extends Bundle
{
}
