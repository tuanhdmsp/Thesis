<?php

namespace Main\PasswordBundle\Security;

use Main\PasswordBundle\Entity\Password;
use Main\PasswordBundle\Entity\PasswordGroup;
use Main\PasswordBundle\Services\PasswordAccessManager;
use Main\UserBundle\Entity\User;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\Voter;

class PasswordVoter extends Voter
{
    /**
     * @var PasswordAccessManager
     */
    protected $passwordAccessManager;

    /**
     * @param PasswordAccessManager $passwordAccessManager
     */
    public function __construct(PasswordAccessManager $passwordAccessManager)
    {
         $this->passwordAccessManager = $passwordAccessManager;
    }

    const VIEW = 'password_view';
    const DELETE = 'password_delete';
    const EDIT = 'password_edit';
    const LOGS = 'password_logs';
    const VIEW_ACCESS = 'password_view_access';
    const ADD_ACCESS = 'password_add_access';
    const UPDATE_ACCESS = 'password_update_access';
    const DELETE_ACCESS = 'password_update_access';

    /**
     * @param string $attribute
     * @param mixed  $subject
     *
     * @return bool
     */
    protected function supports($attribute, $subject)
    {
        if (!in_array($attribute, [self::VIEW, self::DELETE, self::EDIT, self::LOGS, self::VIEW_ACCESS, self::ADD_ACCESS, self::UPDATE_ACCESS, self::DELETE_ACCESS])) {
            return false;
        }

        if (!$subject instanceof Password) {
            return false;
        }

        return true;
    }

    /**
     * @param string         $attribute
     * @param Password       $subject
     * @param TokenInterface $token
     *
     * @return bool
     */
    protected function voteOnAttribute($attribute, $subject, TokenInterface $token)
    {
        $user = $token->getUser();

        if (!$user instanceof User) {
            return false;
        }

        /** @var PasswordGroup $post */
        $entity = $subject;

        switch ($attribute) {
            case self::VIEW:
                return $this->passwordAccessManager->hasUserAnyAccessOnPassword($entity, $user);
            case self::EDIT:
            case self::DELETE:
                return $this->passwordAccessManager->hasUserModeratorAccessOnPassword($entity, $user);
            case self::LOGS:
            case self::VIEW_ACCESS:
            case self::ADD_ACCESS:
            case self::UPDATE_ACCESS:
            case self::DELETE_ACCESS:
                return $this->passwordAccessManager->hasUserAdminAccessOnPassword($entity, $user);
        }

        throw new \LogicException('This code should not be reached!');
    }
}
