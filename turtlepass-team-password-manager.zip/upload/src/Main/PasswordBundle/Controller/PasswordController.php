<?php

namespace Main\PasswordBundle\Controller;

use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Controller\Annotations\NamePrefix;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\View\View;
use Main\AppBundle\Controller\FOSRestController;
use Main\PasswordBundle\Container\LogKeys;
use Main\PasswordBundle\Entity\Password;
use Main\PasswordBundle\Entity\PasswordAccess;
use Main\PasswordBundle\Form\Type\AddPasswordAccessType;
use Main\PasswordBundle\Form\Type\EditPasswordAccessType;
use Main\PasswordBundle\Form\Type\EditPasswordType;
use Main\PasswordBundle\Security\PasswordVoter;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * @RouteResource("Password")
 * @NamePrefix("api_")
 */
class PasswordController extends FOSRestController
{
    /**
     * @param string $query
     *
     * @ApiDoc(
     *   description = "Search Password",
     *   section = "Password",
     *   statusCodes = {
     *     200 = "Returned when successful",
     *     401 = "Returned when invalid oauth token"
     *   }
     * )
     *
     * @return View
     */
    public function cgetSearchAction($query)
    {
        $passwordManager = $this->get('main_password.services.password_manager');

        return View::create($passwordManager->searchPasswordByUserAndQuery($this->getUser(), $query))
            ->setContext($this->getContextByUser($this->getUser(), ['ShowPasswordGroup']));
    }

    /**
     * @param int $password
     *
     * @ApiDoc(
     *   description = "Get password by id.",
     *   section = "Password",
     *   statusCodes = {
     *     200 = "Returned when successful",
     *     401 = "Returned when invalid oauth token",
     *     403 = "Returned when password access denied",
     *     404 = "Returned when password not found"
     *   }
     * )
     *
     * @return View
     *
     * @throws NotFoundHttpException
     */
    public function getAction($password)
    {
        $passwordManager = $this->get('main_password.services.password_manager');

        $password = $passwordManager->getPasswordByIdAndUser($password, $this->getUser());

        if (!$password instanceof Password) {
            throw new NotFoundHttpException('Password not found.');
        }

        $this->denyAccessUnlessGranted(PasswordVoter::VIEW, $password);

        return View::create($password)
            ->setContext($this->getContextByUser($this->getUser(), $passwordManager->getPasswordSerializerGroups($password, $this->getUser())));
    }

    /**
     * @param int $password
     *
     * @ApiDoc(
     *   description = "Confirm password by id.",
     *   section = "Password",
     *   statusCodes = {
     *     204 = "Returned when successful",
     *     401 = "Returned when invalid oauth token",
     *     403 = "Returned when password access denied",
     *     404 = "Returned when password not found",
     *     409 = "Returned when password logging is not enabled."
     *   }
     * )
     *
     * @Rest\Post("/passwords/{password}/confirm")
     *
     * @return View
     *
     * @throws NotFoundHttpException
     */
    public function postConfirmAction($password)
    {
        $passwordManager = $this->get('main_password.services.password_manager');

        $password = $passwordManager->getPasswordByIdAndUser($password, $this->getUser());

        if (!$password instanceof Password) {
            throw new NotFoundHttpException('Password not found.');
        }

        if (!$password->isLogEnabled()) {
            return $this->view(null, Response::HTTP_CONFLICT);
        }

        $passwordLogManager = $this->get('main_password.services.password_log_manager');

        $passwordLogManager->createPasswordLog($password, LogKeys::KEY_VIEW, $this->getUser());

        return $this->view(null, Response::HTTP_NO_CONTENT);
    }

    /**
     * @param Request  $request
     * @param Password $password
     *
     * @ApiDoc(
     *   description = "Get the list of password accesses.",
     *   section = "Password",
     *   statusCodes = {
     *     200 = "Returned when successful",
     *     401 = "Returned when invalid oauth token",
     *     403 = "Returned when access denied",
     *     404 = "Returned when password not found"
     *   },
     *   filters={
     *      {"name"="query", "dataType"="string"}
     *   }
     * )
     *
     * @Security("is_granted(constant('\\Main\\PasswordBundle\\Security\\PasswordVoter::VIEW_ACCESS'), password)")
     *
     * @return View
     */
    public function cgetAccessesAction(Request $request, Password $password)
    {
        $passwordAccessManager = $this->get('main_password.services.password_access_manager');

        $queryBuilder = $passwordAccessManager->qbAllPasswordAccessesByPassword($password);

        $filterManager = $this->get('uql.query_builder_operation.services.filter_manager');
        $apiManager = $this->get('uniquelibs.api_bundle.services.api_manager');

        return $apiManager->formatQueryBuilder(
            $request,
            $filterManager->executeRequest($request, $queryBuilder, $this->get('main_password.query_builder_mapper.password_access')),
            'api_get_passwords_accesses',
            ['password' => $password->getId()]
        )->setContext($this->getContextByUser($this->getUser()));
    }

    /**
     * @param Password $password
     *
     * @ApiDoc(
     *   description = "Delete password by id.",
     *   section = "Password",
     *   statusCodes = {
     *     204 = "Returned when successful",
     *     401 = "Returned when invalid oauth token",
     *     403 = "Returned when password access denied",
     *     404 = "Returned when password not found"
     *   }
     * )
     *
     * @Security("is_granted(constant('\\Main\\PasswordBundle\\Security\\PasswordVoter::DELETE'), password)")
     *
     * @return View
     */
    public function deleteAction(Password $password)
    {
        $passwordManager = $this->get('main_password.services.password_manager');

        $passwordManager->deletePassword($password);

        return View::create(null, 204);
    }

    /**
     * @param Request  $request
     * @param Password $password
     *
     * @ApiDoc(
     *   description = "Add password access by id.",
     *   section = "Password",
     *   input = "Main\PasswordBundle\Form\Type\AddPasswordAccessType",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     400 = "Returned when form has errors",
     *     401 = "Returned when invalid oauth token",
     *     403 = "Returned when password access denied",
     *     404 = "Returned when password not found"
     *   }
     * )
     *
     * @Security("is_granted(constant('\\Main\\PasswordBundle\\Security\\PasswordVoter::ADD_ACCESS'), password)")
     *
     * @return View
     */
    public function postAccessAction(Request $request, Password $password)
    {
        $access = new PasswordAccess();
        $access->setPassword($password);

        $form = $this->createForm(new AddPasswordAccessType(), $access);

        $form->submit($request);

        if ($form->isValid()) {
            $passwordAccessManager = $this->get('main_password.services.password_access_manager');

            $passwordAccessManager->updatePasswordAccess($access);

            return View::create($access, 201)
                ->setContext($this->getContextByUser($this->getUser()));
        }

        return $this->view($form);
    }

    /**
     * @param Request        $request
     * @param Password       $password
     * @param PasswordAccess $passwordAccess
     *
     * @ApiDoc(
     *   description = "Update password access by id.",
     *   section = "Password",
     *   input = "Main\PasswordBundle\Form\Type\EditPasswordAccessType",
     *   statusCodes = {
     *     200 = "Returned when successfully updated",
     *     400 = "Returned when form has errors",
     *     401 = "Returned when invalid oauth token",
     *     403 = "Returned when password access denied",
     *     404 = "Returned when password or access not found",
     *     409 = "Returned when trying to update your own access without group access"
     *   }
     * )
     *
     * @Security("is_granted(constant('\\Main\\PasswordBundle\\Security\\PasswordVoter::UPDATE_ACCESS'), password)")
     *
     * @return View
     */
    public function putAccessAction(Request $request, Password $password, PasswordAccess $passwordAccess)
    {
        if ($passwordAccess->getPassword()->getId() != $password->getId()) {
            throw new AccessDeniedException('Access denied');
        }

        $passwordAccessManager = $this->get('main_password.services.password_access_manager');

        if ($passwordAccess->getUser()->getId() == $this->getUser()->getId()) {
            if (!$passwordAccessManager->hasUserAdminAccessOnPasswordGroup($password->getPasswordGroup(), $this->getUser())) {
                return $this->view(null, 409);
            }
        }

        $form = $this->createForm(new EditPasswordAccessType(), $passwordAccess);

        $form->submit($request);

        if ($form->isValid()) {
            $passwordAccessManager->updatePasswordAccess($passwordAccess);

            return View::create($passwordAccess, 200)
                ->setContext($this->getContextByUser($this->getUser()));
        }

        return $this->view($form);
    }

    /**
     * @param Password       $password
     * @param PasswordAccess $passwordAccess
     *
     * @ApiDoc(
     *   description = "Delete password access by id.",
     *   section = "Password",
     *   statusCodes = {
     *     204 = "Returned when successful",
     *     401 = "Returned when invalid oauth token",
     *     403 = "Returned when password access denied",
     *     404 = "Returned when password or access not found",
     *     409 = "Returned when trying to delete your own access without group access"
     *   }
     * )
     *
     * @Security("is_granted(constant('\\Main\\PasswordBundle\\Security\\PasswordVoter::DELETE_ACCESS'), password)")
     *
     * @return View
     */
    public function deleteAccessAction(Password $password, PasswordAccess $passwordAccess)
    {
        if ($passwordAccess->getPassword()->getId() != $password->getId()) {
            throw new AccessDeniedException('Access denied');
        }

        $passwordAccessManager = $this->get('main_password.services.password_access_manager');

        if ($passwordAccess->getUser()->getId() == $this->getUser()->getId()) {
            if (!$passwordAccessManager->hasUserAdminAccessOnPasswordGroup($password->getPasswordGroup(), $this->getUser())) {
                return $this->view(null, 409);
            }
        }

        $passwordAccessManager->removePasswordAccess($passwordAccess);

        return View::create(null, 204);
    }

    /**
     * @param Request  $request
     * @param Password $password
     *
     * @ApiDoc(
     *   description = "Update password.",
     *   section = "Password",
     *   input = "Main\PasswordBundle\Form\Type\EditPasswordType",
     *   statusCodes = {
     *     200 = "Returned when successfully updated",
     *     400 = "Returned when the form has errors",
     *     401 = "Returned when invalid oauth token",
     *     403 = "Returned when password access denied",
     *     404 = "Returned when password not found"
     *   }
     * )
     *
     * @Security("is_granted(constant('\\Main\\PasswordBundle\\Security\\PasswordVoter::EDIT'), password)")
     *
     * @return View
     */
    public function putAction(Request $request, Password $password)
    {
        $form = $this->createForm(new EditPasswordType(), $password);

        $form->submit($request);

        if ($form->isValid()) {
            $passwordManager = $this->get('main_password.services.password_manager');

            $password->setLastUpdateDate(new \DateTime());

            $passwordManager->updatePasswordByUser($password, $this->getUser());

            return View::create($password)
                ->setContext($this->getContextByUser($this->getUser(), $passwordManager->getPasswordSerializerGroups($password, $this->getUser())));
        }

        return $this->view($form);
    }
}
