<?php

namespace Main\PasswordBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Main\UserBundle\Entity\User;

class PasswordRepository extends EntityRepository
{
    /**
     * @param Password $entity
     * @param bool     $flush
     */
    public function save(Password $entity, $flush = true)
    {
        $this->getEntityManager()->persist($entity);

        if (true === $flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * @param Password $entity
     * @param bool     $flush
     */
    public function remove(Password $entity, $flush = true)
    {
        $this->getEntityManager()->remove($entity);

        if (true === $flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * @param int  $passwordId
     * @param User $user
     *
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function qbPasswordByIdAndUser($passwordId, User $user)
    {
        $qb = $this->createQueryBuilder('password');
        $qb
            ->select('password, password_accesses')
            ->leftJoin('password.passwordAccesses', 'password_accesses', 'WITH', 'password_accesses.user = :pUserId')
            ->andWhere('password.id = :pPassword')
            ->setParameter('pPassword', $passwordId)
            ->setParameter('pUserId', $user->getId());

        return $qb;
    }

    /**
     * @param PasswordGroup $passwordGroup
     * @param User          $user
     *
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function qbAllByPasswordGroupAndUser(PasswordGroup $passwordGroup, User $user)
    {
        $qb = $this->createQueryBuilder('password');
        $qb
            ->select('password, password_accesses')
            ->innerJoin('password.passwordGroup', 'password_group')
            ->leftJoin('password_group.passwordGroupAccesses', 'password_group_accesses', 'WITH', 'password_group_accesses.user = :pUserId')
            ->leftJoin('password.passwordAccesses', 'password_accesses', 'WITH', 'password_accesses.user = :pUserId')
            ->andWhere('password.passwordGroup = :pPasswordGroup')
            ->andWhere(
                $qb->expr()->orX(
                    $qb->expr()->eq('password_accesses.user', ':pUserId'),
                    $qb->expr()->eq('password_group_accesses.user', ':pUserId')
                )
            )
            ->setParameter('pPasswordGroup', $passwordGroup->getId())
            ->setParameter('pUserId', $user->getId());

        return $qb;
    }

    /**
     * @param User   $user
     * @param string $query
     *
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function qbSearchByUserAndQuery(User $user, $query)
    {
        $qb = $this->createQueryBuilder('password');
        $qb
            ->select('password, password_accesses')
            ->innerJoin('password.passwordGroup', 'password_group')
            ->leftJoin('password_group.passwordGroupAccesses', 'password_group_accesses', 'WITH', 'password_group_accesses.user = :pUserId')
            ->leftJoin('password.passwordAccesses', 'password_accesses', 'WITH', 'password_accesses.user = :pUserId')
            ->andWhere(
                $qb->expr()->orX(
                    $qb->expr()->eq('password_accesses.user', ':pUserId'),
                    $qb->expr()->eq('password_group_accesses.user', ':pUserId')
                )
            )
            ->andWhere(
                $qb->expr()->orX(
                    $qb->expr()->like('password.nameCanonical', ':pQuery'),
                    $qb->expr()->like('password.usernameCanonical', ':pQuery'),
                    $qb->expr()->like('password.url', ':pQuery')
                )
            )
            ->setParameter('pQuery', '%' . strtolower($query) . '%')
            ->setParameter('pUserId', $user->getId())
            ->setMaxResults(10);

        return $qb;
    }
}
