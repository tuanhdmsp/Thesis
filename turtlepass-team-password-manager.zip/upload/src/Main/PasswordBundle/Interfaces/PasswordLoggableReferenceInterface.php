<?php

namespace Main\PasswordBundle\Interfaces;

interface PasswordLoggableReferenceInterface
{

}