<?php

namespace Main\UserBundle\Services;

use Doctrine\Common\Persistence\ObjectManager;
use FOS\UserBundle\Model\UserInterface;
use FOS\UserBundle\Util\CanonicalizerInterface;
use Main\LanguageBundle\Services\LanguageManager;
use Main\UserBundle\Entity\User;
use Main\UserBundle\Entity\UserRepository;
use Main\UserBundle\Event\UserEvent;
use Main\UserBundle\Events;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use FOS\UserBundle\Doctrine\UserManager as BaseUserManager;
use Symfony\Component\Security\Core\Encoder\EncoderFactoryInterface;

class UserManager extends BaseUserManager
{
    /**
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * @var LanguageManager
     */
    protected $languageManager;

    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * @param EncoderFactoryInterface  $encoderFactory
     * @param CanonicalizerInterface   $usernameCanonicalizer
     * @param CanonicalizerInterface   $emailCanonicalizer
     * @param ObjectManager            $om
     * @param string                   $class
     * @param UserRepository           $userRepository
     * @param EventDispatcherInterface $eventDispatcher
     */
    public function __construct(EncoderFactoryInterface $encoderFactory, CanonicalizerInterface $usernameCanonicalizer, CanonicalizerInterface $emailCanonicalizer, ObjectManager $om, $class, UserRepository $userRepository, LanguageManager $languageManager, EventDispatcherInterface $eventDispatcher)
    {
        parent::__construct($encoderFactory, $usernameCanonicalizer, $emailCanonicalizer, $om, $class);

        $this->userRepository = $userRepository;
        $this->languageManager = $languageManager;
        $this->eventDispatcher = $eventDispatcher;
    }

    /**
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function qbAllNotDeletedUsers()
    {
        return $this->userRepository->qbAllNotDeleted();
    }

    /**
     * @return UserInterface
     */
    public function createUser()
    {
        $user = parent::createUser();

        if ($user instanceof User) {
            $user->setLanguage($this->languageManager->getDefaultLanguage());
        }

        return $user;
    }

    /**
     * @param UserInterface $user
     */
    public function createGivenUser(UserInterface $user)
    {
        $this->updateUser($user);

        $this->eventDispatcher->dispatch(
            Events::USER_CREATED,
            new UserEvent($user)
        );
    }
}
