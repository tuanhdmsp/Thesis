<?php

namespace Main\UserBundle\Exceptions;

class UnableToChangePasswordException extends \Exception
{
}
