<?php

namespace Main\UserBundle\Form\Type;

use Symfony\Component\Form\FormBuilderInterface;

class EditOwnUserType extends AbstractUserType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->remove('admin')
        ;

        parent::buildForm($builder, $options);
    }
}
