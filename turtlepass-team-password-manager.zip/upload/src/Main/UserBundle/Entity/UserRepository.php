<?php

namespace Main\UserBundle\Entity;

use Doctrine\ORM\EntityRepository;

class UserRepository extends EntityRepository
{
    /**
     * @param User $entity
     * @param bool $flush
     */
    public function save(User $entity, $flush = true)
    {
        $this->getEntityManager()->persist($entity);

        if (true === $flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * @param User $entity
     * @param bool $flush
     */
    public function remove(User $entity, $flush = true)
    {
        $this->getEntityManager()->remove($entity);

        if (true === $flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function qbAllNotDeleted()
    {
        $qb = $this->createQueryBuilder('user')
            ->where('user.deleted = :pFalse')
            ->setParameter('pFalse', false);

        return $qb;
    }
}
