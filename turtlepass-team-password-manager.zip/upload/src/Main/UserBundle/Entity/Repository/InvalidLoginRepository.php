<?php

namespace Main\UserBundle\Entity\Repository;

use UniqueLibs\FOSUserRecaptchaProtectionBundle\Entity\InvalidLoginRepository as BaseRepository;

class InvalidLoginRepository extends BaseRepository
{
}
