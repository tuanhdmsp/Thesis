<?php

namespace Main\TemplateBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MainTemplateBundle extends Bundle
{
}
