(function() {
    app.controller('PasswordTreeController', function(MY_GLOBAL_SETTINGS, $rootScope, $scope, $uibModal, $state, PasswordGroupManager) {

        var self = this;

        $scope.title = "Tree";

        $scope.list = [];

        $scope.loadRootTree = function () {
            PasswordGroupManager.getPasswordGroups().then(function (data) {
                $scope.list = [];
                angular.forEach(data, function (value, key) {
                    $scope.list.push(self.addTree(value));
                });
            });
        };

        this.addTree = function(data) {

            var nodes = [];

            angular.forEach(data.children, function (value, key) {
                nodes.push(self.addTree(value));
            });

            return {
                id: data.id,
                title: data.name,
                icon: data.icon,
                expand: false,
                nodes: nodes
            };
        };

        $scope.openTree = function (nodeId) {
            var found = false;

            angular.forEach($scope.list, function (value, key) {
                if (value.id == nodeId) {
                    found = true;

                    if (value.nodes.length) {
                        value.expand = true;
                    }

                }
            });

            if (found) {
                angular.forEach($scope.list, function (value, key) {
                    if (value.id != nodeId) {
                        value.expand = false;
                    }
                });
            }

            $state.go('overview.group', {groupId: nodeId});
        };

        $scope.loadTree = function (node) {
            node.expand = true;
        };

        $scope.closeNode = function (node) {
            node.expand = false;
        };

        $rootScope.$on('reloadPasswordTree', function(event, mass) {
            $scope.loadRootTree();
        });

        $scope.addPasswordGroup = function () {

            var addPasswordGroupModal = $uibModal.open({
                animation: false,
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/modal/add_or_edit_password_group.html",
                controller: 'ModalAddOrEditPasswordGroupController',
                size: "mg",
                resolve: {
                    passwordGroup: function () {
                        return null;
                    }
                }
            });

            addPasswordGroupModal.result.then(function (response) {
                $scope.loadRootTree();
            });
        };

        $scope.getParents = function (parent){

            if (parent.parent !== undefined) {
                return 1 + $scope.getParents(parent.parent);
            }

            return 1;
        };

        $scope.getRepeat = function (value) {

            var buffer = [];

            for (var i=1; i < value; i++) {
                buffer.push(i);
            }

            return buffer;
        };



        $scope.loadRootTree();
    });

    app.controller('PasswordGroupRedirectController', function(MY_GLOBAL_SETTINGS, $rootScope, $scope, $uibModal, $state, PasswordGroupManager) {
        PasswordGroupManager.getPasswordGroups().then(function (data) {
            if (data[0] !== undefined) {
                $state.go('overview.group', {groupId: data[0].id});
            }
        });
    });

    app.controller('PasswordFilterCtrl', function($rootScope, $scope, MY_GLOBAL_SETTINGS, $state, $stateParams, PasswordManager, PasswordGroupManager, ApiFormatManager) {

        var self = this;
        self.passwords = null;

        this.currentPasswordGroupId = $stateParams.groupId;

        self.listLoading = false;
        self.page = 0;
        self.limit = 10;

        $scope.loadingPasswordGroup = true;
        $scope.breadcrumbs = [];

        this.addToBreadcrumb = function(passwordGroup) {

            $scope.breadcrumbs.unshift({
                id: passwordGroup.id,
                name: passwordGroup.name
            });

            if (passwordGroup.parent !== null) {
                self.addToBreadcrumb(passwordGroup.parent);
            }
        };

        $scope.passwordGroup = null;

        PasswordGroupManager.getPasswordGroup($stateParams.groupId).then(function (data) {
            $scope.passwordGroup = data;

            self.addToBreadcrumb(data);

            $scope.loadingPasswordGroup = false;
        }, function(res) {
            if (res.status == 403) {
                $scope.accessDenied = true;
            }
        });

        $scope.loadMore = function() {

            if (self.listLoading == false && (self.passwords === null || self.passwords !== null && self.passwords.pages > self.page)) {

                self.listLoading = true;
                self.page += 1;

                self.loadPasswords();
            }
        };

        this.loadPasswords = function(pPage, pLimit, appendPasswords) {
            PasswordGroupManager.getPasswordsByPasswordGroup($stateParams.groupId, { page : pPage ? pPage : self.page, limit : pLimit ? pLimit : self.limit }).then(function (data) {
                if (self.passwords !== null && appendPasswords !== false) {
                    var oldItems = self.passwords;

                    angular.forEach(oldItems, function(value, key) {
                        data.push(value);
                    });
                }

                self.passwords = data;
                $scope.$broadcast('content.changed');
                self.listLoading = false;
            });
        };

        $rootScope.$on('reloadPasswordOverview', function(event, mass) {
            self.passwords = [];
            self.page = 1;
            self.limit = 10;
            self.loadPasswords();
        });

    });

    app.controller('PasswordGroupDetailController', function($scope, $rootScope, $state, $translate, MY_GLOBAL_SETTINGS, $stateParams, $uibModal, PasswordGroupManager, ngNotify) {

        var self = this;

        this.accessDenied = false;
        this.loadingPasswordGroup = true;
        this.breadcrumbs = [];

        this.addToBreadcrumb = function(passwordGroup) {

            self.breadcrumbs.unshift({
                id: passwordGroup.id,
                name: passwordGroup.name
            });

            if (passwordGroup.parent !== null) {
                self.addToBreadcrumb(passwordGroup.parent);
            }
        };

        self.passwordGroup = null;

        PasswordGroupManager.getPasswordGroup($stateParams.groupId).then(function (data) {
            self.passwordGroup = data;

            self.addToBreadcrumb(data);

            self.loadingPasswordGroup = false;
        }, function(res) {
            if (res.status == 403) {
                self.accessDenied = true;
            }
        });

        this.addPassword = function() {
            var addPasswordModal = $uibModal.open({
                animation: false,
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/modal/add_or_edit_password.html",
                controller: 'ModalAddOrEditPasswordController',
                size: "mg",
                resolve: {
                    password: null,
                    passwordGroup: function () {
                        return self.passwordGroup;
                    }
                }
            });

            addPasswordModal.result.then(function (response) {
                self.reloadData();
            });
        };

        this.editPasswordGroup = function() {
            var editPasswordGroupModal = $uibModal.open({
                animation: false,
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/modal/add_or_edit_password_group.html",
                controller: 'ModalAddOrEditPasswordGroupController',
                size: "lg",
                resolve: {
                    passwordGroup: function () {
                        return self.passwordGroup;
                    }
                }
            });
        };

        this.movePasswordGroup = function() {
            var movePasswordGroupModal = $uibModal.open({
                animation: false,
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/modal/move_password_group.html",
                controller: 'ModalMovePasswordGroupController',
                size: "mg",
                resolve: {
                    passwordGroup: function () {
                        return self.passwordGroup;
                    }
                }
            });
        };

        this.editPasswordGroupAccess = function() {
            var editPasswordGroupAccessModal = $uibModal.open({
                animation: false,
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/modal/edit_password_group_access.html",
                controller: 'ModalEditAccessPasswordGroupController',
                size: "lg",
                resolve: {
                    passwordGroup: function () {
                        return self.passwordGroup;
                    }
                }
            });
        };

        this.deleteGroup = function(passwordGroup) {
            swal({
                title: $translate.instant('TEXT.ARE_YOU_SURE'),
                text: $translate.instant('PASSWORD_GROUP_MANAGEMENT.TEXT.DELETE_INFORMATION'),
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: $translate.instant('WORDS.YES'),
                cancelButtonText: $translate.instant('WORDS.CLOSE')
            }).then(function() {

                PasswordGroupManager.deletePasswordGroup(passwordGroup.id).then(function() {

                    ngNotify.set($translate.instant('PASSWORD_GROUP_MANAGEMENT.TEXT.DELETE_COMPLETE'), 'success');

                    $rootScope.$broadcast('reloadPasswordTree');

                    if (typeof passwordGroup.parent != 'undefined' && passwordGroup.parent !== null && passwordGroup.parent.id !== null) {
                        $state.go('overview.group', {groupId: passwordGroup.parent.id});
                    } else {
                        $state.go('overview');
                    }
                }, function(res) {
                    if (res.status == 404) {
                        swal($translate.instant('TEXT.RESOURCE_NOT_FOUND'), $translate.instant('TEXT.DELETE_NOT_FOUND'), "error");
                    } if (res.status == 409) {
                        swal($translate.instant('PASSWORD_GROUP_MANAGEMENT.TEXT.DELETE_NOT_ALLOWED_TITLE'), $translate.instant('PASSWORD_GROUP_MANAGEMENT.TEXT.DELETE_NOT_ALLOWED'), "error");
                    } else {
                        swal($translate.instant('TEXT.UNKNOWN_ERROR'), $translate.instant('TEXT.UNKNOWN_ERROR_INFORMATION'), "error");
                    }
                });
            }, function(dismiss) {});
        };

    });

    app.controller('PasswordDetailController', function($scope, $translate, MY_GLOBAL_SETTINGS, $rootScope, $state, $stateParams, $uibModal, ngNotify, PasswordManager, PasswordGroupManager) {

        var self = this;

        this.groupId = $stateParams.groupId;
        this.passwordId = $stateParams.passwordId;
        this.confirmingPassword = false;

        this.icons = ["fa-500px","fa-address-book","fa-address-book-o","fa-address-card","fa-address-card-o","fa-adjust","fa-adn","fa-align-center","fa-align-justify","fa-align-left","fa-align-right","fa-amazon","fa-ambulance","fa-american-sign-language-interpreting","fa-anchor","fa-android","fa-angellist","fa-angle-double-down","fa-angle-double-left","fa-angle-double-right","fa-angle-double-up","fa-angle-down","fa-angle-left","fa-angle-right","fa-angle-up","fa-apple","fa-archive","fa-area-chart","fa-arrow-circle-down","fa-arrow-circle-left","fa-arrow-circle-o-down","fa-arrow-circle-o-left","fa-arrow-circle-o-right","fa-arrow-circle-o-up","fa-arrow-circle-right","fa-arrow-circle-up","fa-arrow-down","fa-arrow-left","fa-arrow-right","fa-arrow-up","fa-arrows","fa-arrows-alt","fa-arrows-h","fa-arrows-v","fa-asl-interpreting","fa-assistive-listening-systems","fa-asterisk","fa-at","fa-audio-description","fa-automobile","fa-backward","fa-balance-scale","fa-ban","fa-bandcamp","fa-bank","fa-bar-chart","fa-bar-chart-o","fa-barcode","fa-bars","fa-bath","fa-bathtub","fa-battery","fa-battery-0","fa-battery-1","fa-battery-2","fa-battery-3","fa-battery-4","fa-battery-empty","fa-battery-full","fa-battery-half","fa-battery-quarter","fa-battery-three-quarters","fa-bed","fa-beer","fa-behance","fa-behance-square","fa-bell","fa-bell-o","fa-bell-slash","fa-bell-slash-o","fa-bicycle","fa-binoculars","fa-birthday-cake","fa-bitbucket","fa-bitbucket-square","fa-bitcoin","fa-black-tie","fa-blind","fa-bluetooth","fa-bluetooth-b","fa-bold","fa-bolt","fa-bomb","fa-book","fa-bookmark","fa-bookmark-o","fa-braille","fa-briefcase","fa-btc","fa-bug","fa-building","fa-building-o","fa-bullhorn","fa-bullseye","fa-bus","fa-buysellads","fa-cab","fa-calculator","fa-calendar","fa-calendar-check-o","fa-calendar-minus-o","fa-calendar-o","fa-calendar-plus-o","fa-calendar-times-o","fa-camera","fa-camera-retro","fa-car","fa-caret-down","fa-caret-left","fa-caret-right","fa-caret-square-o-down","fa-caret-square-o-left","fa-caret-square-o-right","fa-caret-square-o-up","fa-caret-up","fa-cart-arrow-down","fa-cart-plus","fa-cc","fa-cc-amex","fa-cc-diners-club","fa-cc-discover","fa-cc-jcb","fa-cc-mastercard","fa-cc-paypal","fa-cc-stripe","fa-cc-visa","fa-certificate","fa-chain","fa-chain-broken","fa-check","fa-check-circle","fa-check-circle-o","fa-check-square","fa-check-square-o","fa-chevron-circle-down","fa-chevron-circle-left","fa-chevron-circle-right","fa-chevron-circle-up","fa-chevron-down","fa-chevron-left","fa-chevron-right","fa-chevron-up","fa-child","fa-chrome","fa-circle","fa-circle-o","fa-circle-o-notch","fa-circle-thin","fa-clipboard","fa-clock-o","fa-clone","fa-close","fa-cloud","fa-cloud-download","fa-cloud-upload","fa-cny","fa-code","fa-code-fork","fa-codepen","fa-codiepie","fa-coffee","fa-cog","fa-cogs","fa-columns","fa-comment","fa-comment-o","fa-commenting","fa-commenting-o","fa-comments","fa-comments-o","fa-compass","fa-compress","fa-connectdevelop","fa-contao","fa-copy","fa-copyright","fa-creative-commons","fa-credit-card","fa-credit-card-alt","fa-crop","fa-crosshairs","fa-css3","fa-cube","fa-cubes","fa-cut","fa-cutlery","fa-dashboard","fa-dashcube","fa-database","fa-deaf","fa-deafness","fa-dedent","fa-delicious","fa-desktop","fa-deviantart","fa-diamond","fa-digg","fa-dollar","fa-dot-circle-o","fa-download","fa-dribbble","fa-drivers-license","fa-drivers-license-o","fa-dropbox","fa-drupal","fa-edge","fa-edit","fa-eercast","fa-eject","fa-ellipsis-h","fa-ellipsis-v","fa-empire","fa-envelope","fa-envelope-o","fa-envelope-open","fa-envelope-open-o","fa-envelope-square","fa-envira","fa-eraser","fa-etsy","fa-eur","fa-euro","fa-exchange","fa-exclamation","fa-exclamation-circle","fa-exclamation-triangle","fa-expand","fa-expeditedssl","fa-external-link","fa-external-link-square","fa-eye","fa-eye-slash","fa-eyedropper","fa-fa","fa-facebook","fa-facebook-f","fa-facebook-official","fa-facebook-square","fa-fast-backward","fa-fast-forward","fa-fax","fa-feed","fa-female","fa-fighter-jet","fa-file","fa-file-archive-o","fa-file-audio-o","fa-file-code-o","fa-file-excel-o","fa-file-image-o","fa-file-movie-o","fa-file-o","fa-file-pdf-o","fa-file-photo-o","fa-file-picture-o","fa-file-powerpoint-o","fa-file-sound-o","fa-file-text","fa-file-text-o","fa-file-video-o","fa-file-word-o","fa-file-zip-o","fa-files-o","fa-film","fa-filter","fa-fire","fa-fire-extinguisher","fa-firefox","fa-first-order","fa-flag","fa-flag-checkered","fa-flag-o","fa-flash","fa-flask","fa-flickr","fa-floppy-o","fa-folder","fa-folder-o","fa-folder-open","fa-folder-open-o","fa-font","fa-font-awesome","fa-fonticons","fa-fort-awesome","fa-forumbee","fa-forward","fa-foursquare","fa-free-code-camp","fa-frown-o","fa-futbol-o","fa-gamepad","fa-gavel","fa-gbp","fa-ge","fa-gear","fa-gears","fa-genderless","fa-get-pocket","fa-gg","fa-gg-circle","fa-gift","fa-git","fa-git-square","fa-github","fa-github-alt","fa-github-square","fa-gitlab","fa-gittip","fa-glass","fa-glide","fa-glide-g","fa-globe","fa-google","fa-google-plus","fa-google-plus-circle","fa-google-plus-official","fa-google-plus-square","fa-google-wallet","fa-graduation-cap","fa-gratipay","fa-grav","fa-group","fa-h-square","fa-hacker-news","fa-hand-grab-o","fa-hand-lizard-o","fa-hand-o-down","fa-hand-o-left","fa-hand-o-right","fa-hand-o-up","fa-hand-paper-o","fa-hand-peace-o","fa-hand-pointer-o","fa-hand-rock-o","fa-hand-scissors-o","fa-hand-spock-o","fa-hand-stop-o","fa-handshake-o","fa-hard-of-hearing","fa-hashtag","fa-hdd-o","fa-header","fa-headphones","fa-heart","fa-heart-o","fa-heartbeat","fa-history","fa-home","fa-hospital-o","fa-hotel","fa-hourglass","fa-hourglass-1","fa-hourglass-2","fa-hourglass-3","fa-hourglass-end","fa-hourglass-half","fa-hourglass-o","fa-hourglass-start","fa-houzz","fa-html5","fa-i-cursor","fa-id-badge","fa-id-card","fa-id-card-o","fa-ils","fa-image","fa-imdb","fa-inbox","fa-indent","fa-industry","fa-info","fa-info-circle","fa-inr","fa-instagram","fa-institution","fa-internet-explorer","fa-intersex","fa-ioxhost","fa-italic","fa-joomla","fa-jpy","fa-jsfiddle","fa-key","fa-keyboard-o","fa-krw","fa-language","fa-laptop","fa-lastfm","fa-lastfm-square","fa-leaf","fa-leanpub","fa-legal","fa-lemon-o","fa-level-down","fa-level-up","fa-life-bouy","fa-life-buoy","fa-life-ring","fa-life-saver","fa-lightbulb-o","fa-line-chart","fa-link","fa-linkedin","fa-linkedin-square","fa-linode","fa-linux","fa-list","fa-list-alt","fa-list-ol","fa-list-ul","fa-location-arrow","fa-lock","fa-long-arrow-down","fa-long-arrow-left","fa-long-arrow-right","fa-long-arrow-up","fa-low-vision","fa-magic","fa-magnet","fa-mail-forward","fa-mail-reply","fa-mail-reply-all","fa-male","fa-map","fa-map-marker","fa-map-o","fa-map-pin","fa-map-signs","fa-mars","fa-mars-double","fa-mars-stroke","fa-mars-stroke-h","fa-mars-stroke-v","fa-maxcdn","fa-meanpath","fa-medium","fa-medkit","fa-meetup","fa-meh-o","fa-mercury","fa-microchip","fa-microphone","fa-microphone-slash","fa-minus","fa-minus-circle","fa-minus-square","fa-minus-square-o","fa-mixcloud","fa-mobile","fa-mobile-phone","fa-modx","fa-money","fa-moon-o","fa-mortar-board","fa-motorcycle","fa-mouse-pointer","fa-music","fa-navicon","fa-neuter","fa-newspaper-o","fa-object-group","fa-object-ungroup","fa-odnoklassniki","fa-odnoklassniki-square","fa-opencart","fa-openid","fa-opera","fa-optin-monster","fa-outdent","fa-pagelines","fa-paint-brush","fa-paper-plane","fa-paper-plane-o","fa-paperclip","fa-paragraph","fa-paste","fa-pause","fa-pause-circle","fa-pause-circle-o","fa-paw","fa-paypal","fa-pencil","fa-pencil-square","fa-pencil-square-o","fa-percent","fa-phone","fa-phone-square","fa-photo","fa-picture-o","fa-pie-chart","fa-pied-piper","fa-pied-piper-alt","fa-pied-piper-pp","fa-pinterest","fa-pinterest-p","fa-pinterest-square","fa-plane","fa-play","fa-play-circle","fa-play-circle-o","fa-plug","fa-plus","fa-plus-circle","fa-plus-square","fa-plus-square-o","fa-podcast","fa-power-off","fa-print","fa-product-hunt","fa-puzzle-piece","fa-qq","fa-qrcode","fa-question","fa-question-circle","fa-question-circle-o","fa-quora","fa-quote-left","fa-quote-right","fa-ra","fa-random","fa-ravelry","fa-rebel","fa-recycle","fa-reddit","fa-reddit-alien","fa-reddit-square","fa-refresh","fa-registered","fa-remove","fa-renren","fa-reorder","fa-repeat","fa-reply","fa-reply-all","fa-resistance","fa-retweet","fa-rmb","fa-road","fa-rocket","fa-rotate-left","fa-rotate-right","fa-rouble","fa-rss","fa-rss-square","fa-rub","fa-ruble","fa-rupee","fa-s15","fa-safari","fa-save","fa-scissors","fa-scribd","fa-search","fa-search-minus","fa-search-plus","fa-sellsy","fa-send","fa-send-o","fa-server","fa-share","fa-share-alt","fa-share-alt-square","fa-share-square","fa-share-square-o","fa-shekel","fa-sheqel","fa-shield","fa-ship","fa-shirtsinbulk","fa-shopping-bag","fa-shopping-basket","fa-shopping-cart","fa-shower","fa-sign-in","fa-sign-language","fa-sign-out","fa-signal","fa-signing","fa-simplybuilt","fa-sitemap","fa-skyatlas","fa-skype","fa-slack","fa-sliders","fa-slideshare","fa-smile-o","fa-snapchat","fa-snapchat-ghost","fa-snapchat-square","fa-snowflake-o","fa-soccer-ball-o","fa-sort","fa-sort-alpha-asc","fa-sort-alpha-desc","fa-sort-amount-asc","fa-sort-amount-desc","fa-sort-asc","fa-sort-desc","fa-sort-down","fa-sort-numeric-asc","fa-sort-numeric-desc","fa-sort-up","fa-soundcloud","fa-space-shuttle","fa-spinner","fa-spoon","fa-spotify","fa-square","fa-square-o","fa-stack-exchange","fa-stack-overflow","fa-star","fa-star-half","fa-star-half-empty","fa-star-half-full","fa-star-half-o","fa-star-o","fa-steam","fa-steam-square","fa-step-backward","fa-step-forward","fa-stethoscope","fa-sticky-note","fa-sticky-note-o","fa-stop","fa-stop-circle","fa-stop-circle-o","fa-street-view","fa-strikethrough","fa-stumbleupon","fa-stumbleupon-circle","fa-subscript","fa-subway","fa-suitcase","fa-sun-o","fa-superpowers","fa-superscript","fa-support","fa-table","fa-tablet","fa-tachometer","fa-tag","fa-tags","fa-tasks","fa-taxi","fa-telegram","fa-television","fa-tencent-weibo","fa-terminal","fa-text-height","fa-text-width","fa-th","fa-th-large","fa-th-list","fa-themeisle","fa-thermometer","fa-thermometer-0","fa-thermometer-1","fa-thermometer-2","fa-thermometer-3","fa-thermometer-4","fa-thermometer-empty","fa-thermometer-full","fa-thermometer-half","fa-thermometer-quarter","fa-thermometer-three-quarters","fa-thumb-tack","fa-thumbs-down","fa-thumbs-o-down","fa-thumbs-o-up","fa-thumbs-up","fa-ticket","fa-times","fa-times-circle","fa-times-circle-o","fa-times-rectangle","fa-times-rectangle-o","fa-tint","fa-toggle-down","fa-toggle-left","fa-toggle-off","fa-toggle-on","fa-toggle-right","fa-toggle-up","fa-trademark","fa-train","fa-transgender","fa-transgender-alt","fa-trash","fa-trash-o","fa-tree","fa-trello","fa-tripadvisor","fa-trophy","fa-truck","fa-try","fa-tty","fa-tumblr","fa-tumblr-square","fa-turkish-lira","fa-tv","fa-twitch","fa-twitter","fa-twitter-square","fa-umbrella","fa-underline","fa-undo","fa-universal-access","fa-university","fa-unlink","fa-unlock","fa-unlock-alt","fa-unsorted","fa-upload","fa-usb","fa-usd","fa-user","fa-user-circle","fa-user-circle-o","fa-user-md","fa-user-o","fa-user-plus","fa-user-secret","fa-user-times","fa-users","fa-vcard","fa-vcard-o","fa-venus","fa-venus-double","fa-venus-mars","fa-viacoin","fa-viadeo","fa-viadeo-square","fa-video-camera","fa-vimeo","fa-vimeo-square","fa-vine","fa-vk","fa-volume-control-phone","fa-volume-down","fa-volume-off","fa-volume-up","fa-warning","fa-wechat","fa-weibo","fa-weixin","fa-whatsapp","fa-wheelchair","fa-wheelchair-alt","fa-wifi","fa-wikipedia-w","fa-window-close","fa-window-close-o","fa-window-maximize","fa-window-minimize","fa-window-restore","fa-windows","fa-won","fa-wordpress","fa-wpbeginner","fa-wpexplorer","fa-wpforms","fa-wrench","fa-xing","fa-xing-square","fa-y-combinator","fa-y-combinator-square","fa-yahoo","fa-yc","fa-yc-square","fa-yelp","fa-yen","fa-yoast","fa-youtube","fa-youtube-play","fa-youtube-square"];

        this.loaded = 2;

        this.radio = {
            model: null
        };

        this.addShareLink = function() {
            $uibModal.open({
                animation: false,
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/modal/share_link.html",
                controller: 'ModalShareLinkController',
                size: "mg"
            });
        };

        this.confirmPassword = function() {
            self.confirmingPassword = true;
            PasswordManager.postPasswordConfirm($stateParams.passwordId).then(function (data) {
                self.loadPassword();
            });
        };

        this.loadPassword = function() {
            PasswordManager.getPassword($stateParams.passwordId).then(function (data) {
                self.confirmingPassword = false;
                self.radio.model = data.icon;
                $scope.password = data;
                self.loaded -= 1;
            });
        };

        $rootScope.$on('passwordChanged', function(event, mass) {
            self.loadPassword();
        });

        this.loadPassword();

        this.updateingIcon = false;
        this.iconErrors = {};
        this.submitIcon = function() {
            if (!self.updateingIcon) {

                self.iconErrors = {};

                self.updateingIcon = true;

                PasswordManager.putPassword($stateParams.passwordId, {icon: self.radio.model}).then(function(response) {
                    self.updateingIcon = false;
                    self.radio.model = response.icon;
                    $scope.password = response;
                }, function(res) {
                    if (res.status == 400 && res.data.errors !== undefined) {
                        self.iconErrors = ApiFormatManager.formatApiFormErrors(res.data.errors.children);
                    }

                    self.updateingIcon = false;
                });
            }

        };

        this.delete = function() {
            swal({
                title: $translate.instant('TEXT.ARE_YOU_SURE'),
                text: $translate.instant('PASSWORD_MANAGEMENT.TEXT.DELETE_INFORMATION'),
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: $translate.instant('WORDS.YES'),
                cancelButtonText: $translate.instant('WORDS.CLOSE')
            }).then(function() {
                PasswordManager.deletePassword($stateParams.passwordId).then(function() {

                    ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.TEXT.DELETE_COMPLETE'), 'success');

                    $state.go('overview.group', {groupId: $stateParams.groupId});

                    $rootScope.$broadcast('reloadPasswordOverview', []);

                }, function(res) {
                    if (res.status == 404) {
                        swal($translate.instant('TEXT.RESOURCE_NOT_FOUND'), $translate.instant('TEXT.DELETE_NOT_FOUND'), "error");
                    } else {
                        swal($translate.instant('TEXT.UNKNOWN_ERROR'), $translate.instant('TEXT.UNKNOWN_ERROR_INFORMATION'), "error");
                    }
                });
            }, function(dismiss) {});
        };

        this.onCopied = function(entity) {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.ENTRY_COPIED', { entry: $translate.instant(entity) }), 'success');
        };

        this.onCopyFailed = function(err, entry, text) {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.COPY_FAILED'), 'error');
            swal($translate.instant(entry), text, "info");
        };

        PasswordGroupManager.getPasswordGroup($stateParams.groupId).then(function (data) {
            $scope.passwordGroup = data;
            self.loaded -= 1;
        });

        $scope.passwordInputType = 'password';

        $scope.togglePasswordVisibility = function(){
            if ($scope.passwordInputType == 'password') {
                $scope.passwordInputType = 'text';
            } else {
                $scope.passwordInputType = 'password';
            }
        };
    });

    app.controller('PasswordOverviewController', function(MY_GLOBAL_SETTINGS, $rootScope, $scope, $state, $translate, $stateParams, ngNotify, ngTableParams, PasswordManager, PasswordGroupManager, ApiFormatManager, $uibModal) {
        
        var self = this;

        $scope.loadingPasswordGroup = true;
        $scope.loadingPasswords = true;
        $scope.accessDenied = false;

        $scope.breadcrumbs = [];
        
        this.addToBreadcrumb = function(passwordGroup) {

            $scope.breadcrumbs.unshift({
                id: passwordGroup.id,
                name: passwordGroup.name
            });
            
            if (passwordGroup.parent !== null) {
                self.addToBreadcrumb(passwordGroup.parent);
            }
        };

        $scope.passwordGroup = null;

        PasswordGroupManager.getPasswordGroup($stateParams.groupId).then(function (data) {
            $scope.passwordGroup = data;
            
            self.addToBreadcrumb(data);

            $scope.loadingPasswordGroup = false;
        }, function(res) {
            if (res.status == 403) {
                $scope.accessDenied = true;
            }
        });


        this.reloadData = function() {
            $scope.tableParams = new ngTableParams({
                page: 1,
                count: 10
            }, {
                total: 0,
                getData: function ($defer, params) {
                    PasswordGroupManager.getPasswordsByPasswordGroup($stateParams.groupId, ApiFormatManager.formatNGTableParametersToRest(params)).then(function (data) {
                        $scope.loadingPasswords = false;
                        params.total(data.total);
                        $defer.resolve(data);
                    });
                }
            });
        };

        this.reloadData();

        $rootScope.$on('reloadPasswordOverview', function(event, mass) {
            $scope.loadingPasswords = true;
            self.reloadData();
        });

        this.onPasswordCopied = function() {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.PASSWORD_COPIED'), 'success');
        };

        this.onPasswordCopyFailed = function(err, password) {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.PASSWORD_COPY_FAILED'), 'error');
            swal($translate.instant('WORDS.PASSWORD'), password.password, "info");
        };

        this.onPinCopied = function() {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.PIN_COPIED'), 'success');
        };

        this.onPinCopyFailed = function(err, password) {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.PIN_COPY_FAILED'), 'error');
            swal($translate.instant('WORDS.PIN'), password.pin, "info");
        };


        this.onUsernameCopied = function() {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.USERNAME_COPIED'), 'success');
        };

        this.onUsernameCopyFailed = function(err) {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.USERNAME_COPY_FAILED'), 'error');
            swal($translate.instant('WORDS.USERNAME'), password.username, "info");
        };

        this.delete = function(password) {
            swal({
                title: $translate.instant('TEXT.ARE_YOU_SURE'),
                text: $translate.instant('PASSWORD_MANAGEMENT.TEXT.DELETE_INFORMATION'),
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: $translate.instant('WORDS.YES'),
                cancelButtonText: $translate.instant('WORDS.CLOSE')
            }).then(function() {
                PasswordManager.deletePassword(password.id).then(function() {
                    self.reloadData();

                    ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.TEXT.DELETE_COMPLETE'), 'success');

                }, function(res) {
                    if (res.status == 404) {
                        swal($translate.instant('TEXT.RESOURCE_NOT_FOUND'), $translate.instant('TEXT.DELETE_NOT_FOUND'), "error");
                    } else {
                        swal($translate.instant('TEXT.UNKNOWN_ERROR'), $translate.instant('TEXT.UNKNOWN_ERROR_INFORMATION'), "error");
                    }
                });
            }, function(dismiss) {});
        };

        $scope.supported = false;
    });


    app.controller('ModalShareLinkController', function($rootScope, $scope, $uibModalInstance, $translate, $stateParams, ngNotify, ApiFormatManager, PasswordManager) {

        $scope.isLaddaWorking = false;

        $scope.formErrors = {};
        $scope.data = {
            mode: "1",
            recipient: "",
            valid_to: ""
        };

        $scope.editingMode = false;

        $scope.loaded = false;

        var self = this;

        $scope.submit = function() {

            $scope.$broadcast('show-errors-check-validity');

            if (!$scope.isLaddaWorking && $scope.modalForm.$valid) {

                $scope.formErrors = {};

                $scope.isLaddaWorking = true;

                self.submitSuccessResponseAdded = function (response) {
                    $uibModalInstance.close(response);
                    ngNotify.set($translate.instant('SHARE_LINK.CREATED_SUCCESSFULLY'), 'success');

                    $rootScope.$broadcast('shareLinkChange');
                };

                self.submitErrorResponse = function (res) {
                    if (res.status == 400 && res.data.errors !== undefined) {
                        $scope.modalForm.$setUntouched();
                        $scope.modalForm.$setPristine();
                        $scope.$broadcast('show-errors-reset');

                        $scope.formErrors = ApiFormatManager.formatApiFormErrors(res.data.errors.children);
                    }

                    $scope.isLaddaWorking = false;
                };

                PasswordManager.postPasswordShares($stateParams.passwordId, $scope.data).then(self.submitSuccessResponseAdded, self.submitErrorResponse);
            }
        };

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    });


    app.controller('ModalAddOrEditPasswordController', function($scope, $uibModalInstance, $translate, ngNotify, ApiFormatManager, UserManager, PasswordManager, PasswordGroupManager, password, passwordGroup) {

        $scope.isLaddaWorking = false;

        $scope.formErrors = {};

        $scope.editingMode = false;

        $scope.passwordInputType = 'password';

        $scope.passwordType = 'plain';

        $scope.passwordOptions = {
            passwordLength: 16,
            addUpper: true,
            addNumbers: true,
            addSymbols: false
        };

        $scope.loaded = false;

        var self = this;

        if (password !== null) {

            PasswordManager.getPassword(password.id).then(function (data) {
                $scope.data = data;
                $scope.loaded = true;
            });

            $scope.editingMode = true;

        } else {
            $scope.data = {
                name: '',
                url: '',
                username: '',
                notice: '',
                custom_fields: []
            };
            $scope.loaded = true;
        }

        $scope.togglePasswordVisibility = function(){
            if ($scope.passwordInputType == 'password') {
                $scope.passwordInputType = 'text';
            } else {
                $scope.passwordInputType = 'password';
            }
        };

        $scope.submit = function() {

            $scope.$broadcast('show-errors-check-validity');

            if (!$scope.isLaddaWorking && $scope.modalForm.$valid) {

                $scope.formErrors = {};

                $scope.isLaddaWorking = true;

                self.submitSuccessResponseAdd = function(response) {
                    $uibModalInstance.close(response);
                    ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.TEXT.PASSWORD_SUCCESSFULLY_ADDED'), 'success');
                };

                self.submitSuccessResponseEdit = function(response) {
                    $uibModalInstance.close(response);
                    ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.TEXT.PASSWORD_SUCCESSFULLY_UPDATED'), 'success');
                };

                self.submitErrorResponse = function(res) {
                    if (res.status == 400 && res.data.errors !== undefined) {
                        $scope.modalForm.$setUntouched();
                        $scope.modalForm.$setPristine();
                        $scope.$broadcast('show-errors-reset');

                        $scope.formErrors = ApiFormatManager.formatApiFormErrors(res.data.errors.children);
                    }

                    $scope.isLaddaWorking = false;
                };

                if ($scope.editingMode) {
                    PasswordManager.putPassword(password.id, $scope.data).then(self.submitSuccessResponseEdit, self.submitErrorResponse);
                } else {
                    PasswordGroupManager.postPlainPassword(passwordGroup.id, $scope.data).then(self.submitSuccessResponseAdd, self.submitErrorResponse);
                }


            }

        };

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    });

    app.controller('ModalAddOrEditPasswordGroupController', function($rootScope, $scope, $uibModalInstance, ApiFormatManager, UserManager, PasswordManager, PasswordGroupManager, passwordGroup) {

        $scope.isLaddaWorking = false;

        $scope.formErrors = {};

        $scope.editingMode = false;

        var self = this;

        $scope.radio = {
            model: null
        };

        if (passwordGroup !== null) {
            $scope.data = passwordGroup;
            $scope.editingMode = true;

            $scope.radio.model = passwordGroup.icon;

        } else {
            $scope.data = {
                name: ''
            };
        }

        $scope.icons = ["fa-500px","fa-address-book","fa-address-book-o","fa-address-card","fa-address-card-o","fa-adjust","fa-adn","fa-align-center","fa-align-justify","fa-align-left","fa-align-right","fa-amazon","fa-ambulance","fa-american-sign-language-interpreting","fa-anchor","fa-android","fa-angellist","fa-angle-double-down","fa-angle-double-left","fa-angle-double-right","fa-angle-double-up","fa-angle-down","fa-angle-left","fa-angle-right","fa-angle-up","fa-apple","fa-archive","fa-area-chart","fa-arrow-circle-down","fa-arrow-circle-left","fa-arrow-circle-o-down","fa-arrow-circle-o-left","fa-arrow-circle-o-right","fa-arrow-circle-o-up","fa-arrow-circle-right","fa-arrow-circle-up","fa-arrow-down","fa-arrow-left","fa-arrow-right","fa-arrow-up","fa-arrows","fa-arrows-alt","fa-arrows-h","fa-arrows-v","fa-asl-interpreting","fa-assistive-listening-systems","fa-asterisk","fa-at","fa-audio-description","fa-automobile","fa-backward","fa-balance-scale","fa-ban","fa-bandcamp","fa-bank","fa-bar-chart","fa-bar-chart-o","fa-barcode","fa-bars","fa-bath","fa-bathtub","fa-battery","fa-battery-0","fa-battery-1","fa-battery-2","fa-battery-3","fa-battery-4","fa-battery-empty","fa-battery-full","fa-battery-half","fa-battery-quarter","fa-battery-three-quarters","fa-bed","fa-beer","fa-behance","fa-behance-square","fa-bell","fa-bell-o","fa-bell-slash","fa-bell-slash-o","fa-bicycle","fa-binoculars","fa-birthday-cake","fa-bitbucket","fa-bitbucket-square","fa-bitcoin","fa-black-tie","fa-blind","fa-bluetooth","fa-bluetooth-b","fa-bold","fa-bolt","fa-bomb","fa-book","fa-bookmark","fa-bookmark-o","fa-braille","fa-briefcase","fa-btc","fa-bug","fa-building","fa-building-o","fa-bullhorn","fa-bullseye","fa-bus","fa-buysellads","fa-cab","fa-calculator","fa-calendar","fa-calendar-check-o","fa-calendar-minus-o","fa-calendar-o","fa-calendar-plus-o","fa-calendar-times-o","fa-camera","fa-camera-retro","fa-car","fa-caret-down","fa-caret-left","fa-caret-right","fa-caret-square-o-down","fa-caret-square-o-left","fa-caret-square-o-right","fa-caret-square-o-up","fa-caret-up","fa-cart-arrow-down","fa-cart-plus","fa-cc","fa-cc-amex","fa-cc-diners-club","fa-cc-discover","fa-cc-jcb","fa-cc-mastercard","fa-cc-paypal","fa-cc-stripe","fa-cc-visa","fa-certificate","fa-chain","fa-chain-broken","fa-check","fa-check-circle","fa-check-circle-o","fa-check-square","fa-check-square-o","fa-chevron-circle-down","fa-chevron-circle-left","fa-chevron-circle-right","fa-chevron-circle-up","fa-chevron-down","fa-chevron-left","fa-chevron-right","fa-chevron-up","fa-child","fa-chrome","fa-circle","fa-circle-o","fa-circle-o-notch","fa-circle-thin","fa-clipboard","fa-clock-o","fa-clone","fa-close","fa-cloud","fa-cloud-download","fa-cloud-upload","fa-cny","fa-code","fa-code-fork","fa-codepen","fa-codiepie","fa-coffee","fa-cog","fa-cogs","fa-columns","fa-comment","fa-comment-o","fa-commenting","fa-commenting-o","fa-comments","fa-comments-o","fa-compass","fa-compress","fa-connectdevelop","fa-contao","fa-copy","fa-copyright","fa-creative-commons","fa-credit-card","fa-credit-card-alt","fa-crop","fa-crosshairs","fa-css3","fa-cube","fa-cubes","fa-cut","fa-cutlery","fa-dashboard","fa-dashcube","fa-database","fa-deaf","fa-deafness","fa-dedent","fa-delicious","fa-desktop","fa-deviantart","fa-diamond","fa-digg","fa-dollar","fa-dot-circle-o","fa-download","fa-dribbble","fa-drivers-license","fa-drivers-license-o","fa-dropbox","fa-drupal","fa-edge","fa-edit","fa-eercast","fa-eject","fa-ellipsis-h","fa-ellipsis-v","fa-empire","fa-envelope","fa-envelope-o","fa-envelope-open","fa-envelope-open-o","fa-envelope-square","fa-envira","fa-eraser","fa-etsy","fa-eur","fa-euro","fa-exchange","fa-exclamation","fa-exclamation-circle","fa-exclamation-triangle","fa-expand","fa-expeditedssl","fa-external-link","fa-external-link-square","fa-eye","fa-eye-slash","fa-eyedropper","fa-fa","fa-facebook","fa-facebook-f","fa-facebook-official","fa-facebook-square","fa-fast-backward","fa-fast-forward","fa-fax","fa-feed","fa-female","fa-fighter-jet","fa-file","fa-file-archive-o","fa-file-audio-o","fa-file-code-o","fa-file-excel-o","fa-file-image-o","fa-file-movie-o","fa-file-o","fa-file-pdf-o","fa-file-photo-o","fa-file-picture-o","fa-file-powerpoint-o","fa-file-sound-o","fa-file-text","fa-file-text-o","fa-file-video-o","fa-file-word-o","fa-file-zip-o","fa-files-o","fa-film","fa-filter","fa-fire","fa-fire-extinguisher","fa-firefox","fa-first-order","fa-flag","fa-flag-checkered","fa-flag-o","fa-flash","fa-flask","fa-flickr","fa-floppy-o","fa-folder","fa-folder-o","fa-folder-open","fa-folder-open-o","fa-font","fa-font-awesome","fa-fonticons","fa-fort-awesome","fa-forumbee","fa-forward","fa-foursquare","fa-free-code-camp","fa-frown-o","fa-futbol-o","fa-gamepad","fa-gavel","fa-gbp","fa-ge","fa-gear","fa-gears","fa-genderless","fa-get-pocket","fa-gg","fa-gg-circle","fa-gift","fa-git","fa-git-square","fa-github","fa-github-alt","fa-github-square","fa-gitlab","fa-gittip","fa-glass","fa-glide","fa-glide-g","fa-globe","fa-google","fa-google-plus","fa-google-plus-circle","fa-google-plus-official","fa-google-plus-square","fa-google-wallet","fa-graduation-cap","fa-gratipay","fa-grav","fa-group","fa-h-square","fa-hacker-news","fa-hand-grab-o","fa-hand-lizard-o","fa-hand-o-down","fa-hand-o-left","fa-hand-o-right","fa-hand-o-up","fa-hand-paper-o","fa-hand-peace-o","fa-hand-pointer-o","fa-hand-rock-o","fa-hand-scissors-o","fa-hand-spock-o","fa-hand-stop-o","fa-handshake-o","fa-hard-of-hearing","fa-hashtag","fa-hdd-o","fa-header","fa-headphones","fa-heart","fa-heart-o","fa-heartbeat","fa-history","fa-home","fa-hospital-o","fa-hotel","fa-hourglass","fa-hourglass-1","fa-hourglass-2","fa-hourglass-3","fa-hourglass-end","fa-hourglass-half","fa-hourglass-o","fa-hourglass-start","fa-houzz","fa-html5","fa-i-cursor","fa-id-badge","fa-id-card","fa-id-card-o","fa-ils","fa-image","fa-imdb","fa-inbox","fa-indent","fa-industry","fa-info","fa-info-circle","fa-inr","fa-instagram","fa-institution","fa-internet-explorer","fa-intersex","fa-ioxhost","fa-italic","fa-joomla","fa-jpy","fa-jsfiddle","fa-key","fa-keyboard-o","fa-krw","fa-language","fa-laptop","fa-lastfm","fa-lastfm-square","fa-leaf","fa-leanpub","fa-legal","fa-lemon-o","fa-level-down","fa-level-up","fa-life-bouy","fa-life-buoy","fa-life-ring","fa-life-saver","fa-lightbulb-o","fa-line-chart","fa-link","fa-linkedin","fa-linkedin-square","fa-linode","fa-linux","fa-list","fa-list-alt","fa-list-ol","fa-list-ul","fa-location-arrow","fa-lock","fa-long-arrow-down","fa-long-arrow-left","fa-long-arrow-right","fa-long-arrow-up","fa-low-vision","fa-magic","fa-magnet","fa-mail-forward","fa-mail-reply","fa-mail-reply-all","fa-male","fa-map","fa-map-marker","fa-map-o","fa-map-pin","fa-map-signs","fa-mars","fa-mars-double","fa-mars-stroke","fa-mars-stroke-h","fa-mars-stroke-v","fa-maxcdn","fa-meanpath","fa-medium","fa-medkit","fa-meetup","fa-meh-o","fa-mercury","fa-microchip","fa-microphone","fa-microphone-slash","fa-minus","fa-minus-circle","fa-minus-square","fa-minus-square-o","fa-mixcloud","fa-mobile","fa-mobile-phone","fa-modx","fa-money","fa-moon-o","fa-mortar-board","fa-motorcycle","fa-mouse-pointer","fa-music","fa-navicon","fa-neuter","fa-newspaper-o","fa-object-group","fa-object-ungroup","fa-odnoklassniki","fa-odnoklassniki-square","fa-opencart","fa-openid","fa-opera","fa-optin-monster","fa-outdent","fa-pagelines","fa-paint-brush","fa-paper-plane","fa-paper-plane-o","fa-paperclip","fa-paragraph","fa-paste","fa-pause","fa-pause-circle","fa-pause-circle-o","fa-paw","fa-paypal","fa-pencil","fa-pencil-square","fa-pencil-square-o","fa-percent","fa-phone","fa-phone-square","fa-photo","fa-picture-o","fa-pie-chart","fa-pied-piper","fa-pied-piper-alt","fa-pied-piper-pp","fa-pinterest","fa-pinterest-p","fa-pinterest-square","fa-plane","fa-play","fa-play-circle","fa-play-circle-o","fa-plug","fa-plus","fa-plus-circle","fa-plus-square","fa-plus-square-o","fa-podcast","fa-power-off","fa-print","fa-product-hunt","fa-puzzle-piece","fa-qq","fa-qrcode","fa-question","fa-question-circle","fa-question-circle-o","fa-quora","fa-quote-left","fa-quote-right","fa-ra","fa-random","fa-ravelry","fa-rebel","fa-recycle","fa-reddit","fa-reddit-alien","fa-reddit-square","fa-refresh","fa-registered","fa-remove","fa-renren","fa-reorder","fa-repeat","fa-reply","fa-reply-all","fa-resistance","fa-retweet","fa-rmb","fa-road","fa-rocket","fa-rotate-left","fa-rotate-right","fa-rouble","fa-rss","fa-rss-square","fa-rub","fa-ruble","fa-rupee","fa-s15","fa-safari","fa-save","fa-scissors","fa-scribd","fa-search","fa-search-minus","fa-search-plus","fa-sellsy","fa-send","fa-send-o","fa-server","fa-share","fa-share-alt","fa-share-alt-square","fa-share-square","fa-share-square-o","fa-shekel","fa-sheqel","fa-shield","fa-ship","fa-shirtsinbulk","fa-shopping-bag","fa-shopping-basket","fa-shopping-cart","fa-shower","fa-sign-in","fa-sign-language","fa-sign-out","fa-signal","fa-signing","fa-simplybuilt","fa-sitemap","fa-skyatlas","fa-skype","fa-slack","fa-sliders","fa-slideshare","fa-smile-o","fa-snapchat","fa-snapchat-ghost","fa-snapchat-square","fa-snowflake-o","fa-soccer-ball-o","fa-sort","fa-sort-alpha-asc","fa-sort-alpha-desc","fa-sort-amount-asc","fa-sort-amount-desc","fa-sort-asc","fa-sort-desc","fa-sort-down","fa-sort-numeric-asc","fa-sort-numeric-desc","fa-sort-up","fa-soundcloud","fa-space-shuttle","fa-spinner","fa-spoon","fa-spotify","fa-square","fa-square-o","fa-stack-exchange","fa-stack-overflow","fa-star","fa-star-half","fa-star-half-empty","fa-star-half-full","fa-star-half-o","fa-star-o","fa-steam","fa-steam-square","fa-step-backward","fa-step-forward","fa-stethoscope","fa-sticky-note","fa-sticky-note-o","fa-stop","fa-stop-circle","fa-stop-circle-o","fa-street-view","fa-strikethrough","fa-stumbleupon","fa-stumbleupon-circle","fa-subscript","fa-subway","fa-suitcase","fa-sun-o","fa-superpowers","fa-superscript","fa-support","fa-table","fa-tablet","fa-tachometer","fa-tag","fa-tags","fa-tasks","fa-taxi","fa-telegram","fa-television","fa-tencent-weibo","fa-terminal","fa-text-height","fa-text-width","fa-th","fa-th-large","fa-th-list","fa-themeisle","fa-thermometer","fa-thermometer-0","fa-thermometer-1","fa-thermometer-2","fa-thermometer-3","fa-thermometer-4","fa-thermometer-empty","fa-thermometer-full","fa-thermometer-half","fa-thermometer-quarter","fa-thermometer-three-quarters","fa-thumb-tack","fa-thumbs-down","fa-thumbs-o-down","fa-thumbs-o-up","fa-thumbs-up","fa-ticket","fa-times","fa-times-circle","fa-times-circle-o","fa-times-rectangle","fa-times-rectangle-o","fa-tint","fa-toggle-down","fa-toggle-left","fa-toggle-off","fa-toggle-on","fa-toggle-right","fa-toggle-up","fa-trademark","fa-train","fa-transgender","fa-transgender-alt","fa-trash","fa-trash-o","fa-tree","fa-trello","fa-tripadvisor","fa-trophy","fa-truck","fa-try","fa-tty","fa-tumblr","fa-tumblr-square","fa-turkish-lira","fa-tv","fa-twitch","fa-twitter","fa-twitter-square","fa-umbrella","fa-underline","fa-undo","fa-universal-access","fa-university","fa-unlink","fa-unlock","fa-unlock-alt","fa-unsorted","fa-upload","fa-usb","fa-usd","fa-user","fa-user-circle","fa-user-circle-o","fa-user-md","fa-user-o","fa-user-plus","fa-user-secret","fa-user-times","fa-users","fa-vcard","fa-vcard-o","fa-venus","fa-venus-double","fa-venus-mars","fa-viacoin","fa-viadeo","fa-viadeo-square","fa-video-camera","fa-vimeo","fa-vimeo-square","fa-vine","fa-vk","fa-volume-control-phone","fa-volume-down","fa-volume-off","fa-volume-up","fa-warning","fa-wechat","fa-weibo","fa-weixin","fa-whatsapp","fa-wheelchair","fa-wheelchair-alt","fa-wifi","fa-wikipedia-w","fa-window-close","fa-window-close-o","fa-window-maximize","fa-window-minimize","fa-window-restore","fa-windows","fa-won","fa-wordpress","fa-wpbeginner","fa-wpexplorer","fa-wpforms","fa-wrench","fa-xing","fa-xing-square","fa-y-combinator","fa-y-combinator-square","fa-yahoo","fa-yc","fa-yc-square","fa-yelp","fa-yen","fa-yoast","fa-youtube","fa-youtube-play","fa-youtube-square"];

        $scope.submit = function() {

            $scope.$broadcast('show-errors-check-validity');

            if (!$scope.isLaddaWorking && $scope.modalForm.$valid) {

                $scope.formErrors = {};

                $scope.isLaddaWorking = true;

                self.submitSuccessResponse = function(response) {
                    $rootScope.$broadcast('reloadPasswordTree');
                    $uibModalInstance.close(response);
                };

                self.submitErrorResponse = function(res) {
                    if (res.status == 400 && res.data.errors !== undefined) {
                        $scope.modalForm.$setUntouched();
                        $scope.modalForm.$setPristine();
                        $scope.$broadcast('show-errors-reset');

                        $scope.formErrors = ApiFormatManager.formatApiFormErrors(res.data.errors.children);
                    }

                    $scope.isLaddaWorking = false;
                };

                if ($scope.editingMode) {
                    PasswordGroupManager.putPasswordGroup(passwordGroup.id, $scope.data.name, $scope.radio.model).then(self.submitSuccessResponse, self.submitErrorResponse);
                } else {
                    PasswordGroupManager.postPasswordGroup($scope.data.name, $scope.radio.model, null).then(self.submitSuccessResponse, self.submitErrorResponse);
                }


            }

        };

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    });

    app.controller('EditAccessPasswordController', function(MY_GLOBAL_SETTINGS, $scope, $stateParams, ngTableParams, ApiFormatManager, UserManager, PasswordManager, PasswordGroupManager) {

        var self = this;

        PasswordManager.getPassword($stateParams.passwordId).then(function (data) {
            $scope.data = data;
        });

        PasswordGroupManager.getPasswordGroup($stateParams.groupId).then(function (data) {
            $scope.passwordGroup = data;
        }, function(res) {
        });


        $scope.getUsers = function(val) {
            var isnum = /^\d+$/.test(val);
            var query = "where id = '" + val.replace(/'/g, "\\'") + "' OR full_name LIKE '%" + val.replace(/'/g, "\\'") + "%' OR email LIKE '%" + val.replace(/'/g, "\\'") + "%'";

            if (!isnum) {
                query = "where full_name LIKE '%" + val.replace(/'/g, "\\'") + "%' OR email LIKE '%" + val.replace(/'/g, "\\'") + "%'";
            }

            return UserManager.getUsers({
                'query': query
            }).then(function(response){
                return response;
            });
        };

        $scope.user = null;

        $scope.loaded = false;

        $scope.showAlreadyAddedError = false;

        $scope.currentUser = MY_GLOBAL_SETTINGS.user;

        $scope.typeaheadOnSelect = function($item, $model, $label, $event) {

            PasswordManager.postPasswordAccess($stateParams.passwordId, $item.id, 1).then(function (data) {
                self.reloadData();
                $scope.user = null;
            }, function(res) {
                if (res.status == 400 && res.data.errors !== undefined) {
                    $scope.user = null;
                }
            });

        };

        $scope.selectRights = [
            { id: '', title: 'All'},
            { id: 1, title: 'Read-Only'},
            { id: 2, title: 'Moderator'},
            { id: 3, title: 'Administrator'}
        ];

        $scope.delete = function(passwordAccess) {

            PasswordManager.deletePasswordAccess($stateParams.passwordId, passwordAccess.id).then(function (data) {
                self.reloadData();
            }, function(res) {

            });
        };

        $scope.updateAccess = function(passwordAccess, right) {

            PasswordManager.putPasswordAccess($stateParams.passwordId, passwordAccess.id, right).then(function (data) {
                self.reloadData();
            }, function(res) {
            });
        };

        self.reloadData = function() {
            $scope.tableParams = new ngTableParams({
                page: 1,
                count: 10,
                filter: {'right': ""}
            }, {
                total: 0,
                getData: function ($defer, params) {
                    PasswordManager.getPasswordAccesses($stateParams.passwordId, ApiFormatManager.formatNGTableParametersToRest(params)).then(function (data) {
                        $scope.loadingPasswords = false;
                        params.total(data.total);
                        $defer.resolve(data);
                        $scope.loaded = true;
                    });
                }
            });
        };

        self.reloadData();

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    });

    app.controller('ModalEditAccessPasswordGroupController', function(MY_GLOBAL_SETTINGS, $scope, $uibModalInstance, ngTableParams, ApiFormatManager, UserManager, PasswordGroupManager, passwordGroup) {

        var self = this;

        $scope.passwordGroup = passwordGroup;

        $scope.getUsers = function(val) {
            var isnum = /^\d+$/.test(val);
            var query = "where id = '" + val.replace(/'/g, "\\'") + "' OR full_name LIKE '%" + val.replace(/'/g, "\\'") + "%' OR email LIKE '%" + val.replace(/'/g, "\\'") + "%'";

            if (!isnum) {
                query = "where full_name LIKE '%" + val.replace(/'/g, "\\'") + "%' OR email LIKE '%" + val.replace(/'/g, "\\'") + "%'";
            }

            return UserManager.getUsers({
                'query': query
            }).then(function(response){
                return response;
            });
        };

        $scope.user = null;

        $scope.selectRights = [
            { id: '', title: 'All'},
            { id: 1, title: 'Read-Only'},
            { id: 2, title: 'Moderator'},
            { id: 3, title: 'Administrator'}
        ];


        $scope.showAlreadyAddedError = false;

        $scope.currentUser = MY_GLOBAL_SETTINGS.user;

        $scope.typeaheadOnSelect = function($item, $model, $label, $event) {
            $scope.showAlreadyAddedError = false;

            PasswordGroupManager.postPasswordGroupAccess(passwordGroup.id, $item.id, 1).then(function (data) {
                self.reloadData();
                $scope.user = null;
            }, function(res) {

                if (res.status == 400 && res.data.errors !== undefined) {
                    $scope.user = null;
                }

                if (res.status == 400 && res.data.errors !== undefined && res.data.errors.children.user.errors[0] == "User has already password group right.") {
                    $scope.showAlreadyAddedError = true;
                }
            });

        };

        $scope.delete = function(passwordGroupAccess) {

            PasswordGroupManager.deletePasswordGroupAccess(passwordGroup.id, passwordGroupAccess.id).then(function (data) {
                self.reloadData();
            }, function(res) {

            });
        };

        $scope.updateAccess = function(passwordGroupAccess, right) {

            PasswordGroupManager.putPasswordGroupAccess(passwordGroup.id, passwordGroupAccess.id, right).then(function (data) {
                self.reloadData();
            }, function(res) {

            });
        };

        self.reloadData = function() {
            $scope.tableParams = new ngTableParams({
                page: 1,
                count: 10,
                filter: {'right': ""}
            }, {
                total: 0,
                getData: function ($defer, params) {
                    PasswordGroupManager.getPasswordGroupAccesses(passwordGroup.id, ApiFormatManager.formatNGTableParametersToRest(params)).then(function (data) {
                        $scope.loadingPasswords = false;
                        params.total(data.total);
                        $defer.resolve(data);
                    });
                }
            });
        };

        self.reloadData();

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    });

    app.controller('ModalMovePasswordGroupController', function(MY_GLOBAL_SETTINGS, $rootScope, $scope, $translate, $uibModalInstance, ngNotify, PasswordGroupManager, passwordGroup) {

        var self = this;

        $scope.loaded = false;
        $scope.passwordGroup = passwordGroup;

        this.defaultGroup = {
            'id': null,
            'name': '------',
            'icon': null,
            'layer': []
        };

        $scope.getGroups = [this.defaultGroup];
        $scope.selected = { state: null };

        this.addGroup = function(layer, group) {

            if (group.id != $scope.passwordGroup.id) {

                var layers = [];

                for (var i = 0; i < layer; i++) {
                    layers.push(i);
                }

                $scope.getGroups.push({
                    'id': group.id,
                    'name': group.name,
                    'icon': group.icon,
                    'right': group.right,
                    'layer': layers
                });

                if (group.children !== undefined && group.children.length) {
                    angular.forEach(group.children, function (value, key) {
                        self.addGroup(layer+1, value);
                    });
                }

            }
        };

        PasswordGroupManager.getPasswordGroups().then(function (data) {
            angular.forEach(data, function (value, key) {
                self.addGroup(0, value);
            });

            if ($scope.passwordGroup.parent !== null) {
                $scope.selected.state = $scope.passwordGroup.parent.id;
            }

            $scope.loaded = true;
        });

        $scope.submit = function() {

            $scope.laddaLoading = true;

            PasswordGroupManager.putPasswordGroupMove($scope.passwordGroup.id, $scope.selected.state).then(function() {
                $scope.laddaLoading = false;

                $rootScope.$broadcast('reloadPasswordTree');
                ngNotify.set($translate.instant('PASSWORD_GROUP_MANAGEMENT.TEXT.PASSWORD_GROUP_MOVED'), 'success');

                $uibModalInstance.close();

            }, function(res) {
                $scope.laddaLoading = false;
            });
        };

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    });

    app.controller('ChangePasswordController', function(MY_GLOBAL_SETTINGS, $scope, $translate, ApiFormatManager, PasswordManager) {

        var self = this;

        this.data = {
            current_password: '',
            new_password: '',
            new_password_repeat: ''
        };

        this.formErrors = {};

        this.laddaLoading = false;

        this.submit = function() {

            $scope.$broadcast('show-errors-check-validity');

            self.formErrors = {};

            if (self.data.new_password != self.data.new_password_repeat) {
                self.formErrors.new_password_repeat = $translate.instant('VALIDATION.PASSWORD_EQUALS');
            }

            if ($scope.changePasswordForm.$valid && self.data.new_password == self.data.new_password_repeat) {
                self.laddaLoading = true;
                PasswordManager.changePassword(self.data.current_password, self.data.new_password).then(function() {
                    self.laddaLoading = false;
                    self.data = {};
                    $scope.changePasswordForm.$setUntouched();
                    $scope.changePasswordForm.$setPristine();
                    $scope.$broadcast('show-errors-reset');
                    swal($translate.instant('SETTINGS.TEXT.PASSWORD_CHANGED'), $translate.instant('SETTINGS.TEXT.PASSWORD_CHANGED_INFORMATION'), "success");
                }, function(res) {
                    if (res.status == 400 && res.data.errors !== undefined) {
                        $scope.changePasswordForm.$setUntouched();
                        $scope.changePasswordForm.$setPristine();
                        $scope.$broadcast('show-errors-reset');
                        self.formErrors = ApiFormatManager.formatApiFormErrors(res.data.errors.children);
                    }
                    self.laddaLoading = false;
                });
            }
        };
    });

    app.controller('PasswordSearchController', function(MY_GLOBAL_SETTINGS, $scope, $state, PasswordManager) {

        var self = this;

        $scope.searchPassword = function(val) {
            return PasswordManager.searchPassword(val.replace(/'/g, "\\'")).then(function(response){
                return response;
            });
        };

        $scope.password = null;

        $scope.typeaheadOnSelect = function($item, $model, $label, $event) {

            $state.go('overview.group.details.main', {groupId: $scope.password.password_group.id, passwordId: $scope.password.id});

            $scope.password = null;
        };
    });

    app.controller('PasswordLogController', function(MY_GLOBAL_SETTINGS, $scope, $stateParams, ngTableParams, ApiFormatManager, PasswordManager) {

        var self = this;

        this.loaded = false;

        self.selectLogKeys = [
            { id: '', title: 'All'},
            { id: 'CREATED', title: 'CREATED'},
            { id: 'UPDATED', title: 'UPDATED'},
            { id: 'VIEW', title: 'VIEW'},
            { id: 'SHARED', title: 'SHARED'}
        ];

        self.reloadData = function() {
            $scope.tableParams = new ngTableParams({
                page: 1,
                count: 10,
                filter: {'password_log.key': ""}
            }, {
                total: 0,
                getData: function ($defer, params) {
                    PasswordManager.getPasswordLogs($stateParams.passwordId, ApiFormatManager.formatNGTableParametersToRest(params)).then(function (data) {
                        params.total(data.total);
                        $defer.resolve(data);
                        self.loaded = true;
                    });
                }
            });
        };

        self.reloadData();

    });

    app.controller('PasswordShareController', function(MY_GLOBAL_SETTINGS, $location, $rootScope, $scope, $stateParams, $translate, ngTableParams, ngNotify, ApiFormatManager, PasswordManager) {

        var self = this;

        this.loaded = false;

        $scope.selectKeys = [
            { id: '', title: 'All'},
            { id: '1', title: 'READ'},
            { id: '2', title: 'WRITE'}
        ];

        this.onCopied = function() {
            ngNotify.set($translate.instant('SHARE_LINK.SHARE_LINK_COPIED'), 'success');
        };

        this.onCopyFailed = function(err) {
            ngNotify.set($translate.instant('PASSWORD_MANAGEMENT.COPY_FAILED'), 'error');
        };

        $rootScope.$on('shareLinkChange', function(event, mass) {
            self.reloadData();
        });

        this.delete = function(passwordShareLinkId) {
            swal({
                title: $translate.instant('TEXT.ARE_YOU_SURE'),
                text: $translate.instant('SHARE_LINK.DELETE_SHARE_LINK'),
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: $translate.instant('WORDS.YES'),
                cancelButtonText: $translate.instant('WORDS.CLOSE')
            }).then(function() {
                PasswordManager.deletePasswordShare($stateParams.passwordId, passwordShareLinkId).then(function() {

                    ngNotify.set($translate.instant('SHARE_LINK.DELETE_SHARE_LINK_COMPLETE'), 'success');

                    $rootScope.$broadcast('shareLinkChange');

                }, function(res) {
                    if (res.status == 404) {
                        swal($translate.instant('TEXT.RESOURCE_NOT_FOUND'), $translate.instant('TEXT.DELETE_NOT_FOUND'), "error");
                    } else {
                        swal($translate.instant('TEXT.UNKNOWN_ERROR'), $translate.instant('TEXT.UNKNOWN_ERROR_INFORMATION'), "error");
                    }
                });
            }, function(dismiss) {});
        };

        self.reloadData = function() {
            $scope.tableParams = new ngTableParams({
                page: 1,
                count: 10
            }, {
                total: 0,
                getData: function ($defer, params) {
                    PasswordManager.getPasswordShares($stateParams.passwordId, ApiFormatManager.formatNGTableParametersToRest(params)).then(function (data) {

                        angular.forEach(data, function(value, key) {
                            data[key].link = $location.host() + '/password-share#/password-share/' + value.id + '/' + encodeURI(value.token);
                        });

                        params.total(data.total);
                        $defer.resolve(data);
                        self.loaded = true;
                    });
                }
            });
        };

        self.reloadData();

    });

})();