(function() {
    app.config(function(
        $stateProvider,
        $urlRouterProvider,
        $translateProvider,
        RestangularProvider,
        laddaProvider,
        showErrorsConfigProvider,
        cfpLoadingBarProvider,
        tmhDynamicLocaleProvider,
        MY_GLOBAL_SETTINGS) {

        $translateProvider.useStaticFilesLoader({
            prefix: MY_GLOBAL_SETTINGS.languageBaseUrl,
            suffix: '.json'
        });

        $translateProvider.preferredLanguage(MY_GLOBAL_SETTINGS.preferredLanguage);
        $translateProvider.useSanitizeValueStrategy('sanitizeParameters');
        
        tmhDynamicLocaleProvider.localeLocationPattern('/components/angular-i18n/angular-locale_{{locale}}.js');

        cfpLoadingBarProvider.includeSpinner = false;

        showErrorsConfigProvider.showSuccess(true);

        laddaProvider.setOption({
            style: 'expand-right'
        });

        RestangularProvider.setBaseUrl(MY_GLOBAL_SETTINGS.baseUrl);

        if (typeof MY_GLOBAL_SETTINGS.token !== "undefined" && MY_GLOBAL_SETTINGS.token !== "") {
            RestangularProvider.setDefaultHeaders({
                "Authorization": "Bearer " + MY_GLOBAL_SETTINGS.token,
                "Accept-Language": MY_GLOBAL_SETTINGS.user.language.id
            });
        }

        RestangularProvider.addResponseInterceptor(function(data, operation) {
            var extractedData;
            if (operation === "getList") {
                if (data._embedded !== undefined && data._embedded.items !== undefined) {
                    extractedData = data._embedded.items;
                    if (data.limit !== undefined) {
                        extractedData.limit = data.limit;
                    }
                    if (data.total !== undefined) {
                        extractedData.total = data.total;
                    }
                    if (data.pages !== undefined) {
                        extractedData.pages = data.pages;
                    }
                } else {
                    extractedData = data;
                }
            } else {
                extractedData = data;
            }
            return extractedData;
        });

        $urlRouterProvider.otherwise("/overview");

        $stateProvider

            // Overview
            .state('overview', {
                url: "/overview",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview.html"
            })
            .state('overview.group', {
                url: "/group/:groupId",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/filter.html"
            })
            .state('overview.group.add', {
                url: "/add",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/add.html"
            })
            .state('overview.group.details', {
                url: "/details/:passwordId",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/details.html"
            })
            .state('overview.group.details.main', {
                url: "/main",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/details/main.html"
            })
            .state('overview.group.details.icon', {
                url: "/icon",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/details/icon.html"
            })
            .state('overview.group.details.edit', {
                url: "/edit",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/details/edit.html"
            })
            .state('overview.group.details.edit_permissions', {
                url: "/edit-permissions",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/details/edit_password_access.html"
            })
            .state('overview.group.details.logs', {
                url: "/logs",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/details/logs.html"
            })
            .state('overview.group.details.shares', {
                url: "/shares",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/overview/details/shares.html"
            })

            // User
            .state('user', {
                url: "/user",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/user.html"
            })

            // Profile
            .state('profile', {
                url: "/profile",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile.html"
            })
            .state('profile.change_password', {
                url: "/change_password",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile/change_password.html"
            })
            .state('profile.global_settings', {
                url: "/global-settings",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile/global_settings.html"
            })
            .state('profile.tokens', {
                url: "/tokens",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile/tokens.html"
            })
            .state('profile.token_add', {
                url: "/token/add",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile/token/add.html"
            })
            .state('profile.edit_own', {
                url: "/profile/editown",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile/edit_own.html"
            })
            .state('profile.check_update', {
                url: "/check-update",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile/check_update.html"
            })
            .state('profile.login_accesses', {
                url: "/login-accesses",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile/login_accesses.html"
            })
            .state('profile.auth', {
                url: "/auth",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/profile/auth.html"
            })

            // Password Share
            .state('password_share', {
                url: "/password-share/:passwordShareLinkId/:securityToken",
                templateUrl: MY_GLOBAL_SETTINGS.templateUrl + "partials/password_share.html"
            })
        ;
    });
})();