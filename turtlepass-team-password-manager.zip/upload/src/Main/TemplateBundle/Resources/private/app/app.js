var app = angular.module('turtlepass', [
    'pascalprecht.translate', 
    'ui.router', 
    'ui.bootstrap', 
    'ui.bootstrap.showErrors', 
    'restangular', 
    'angular-ladda', 
    'ngTable',
    'ngSanitize',
    'angular-loading-bar',
    'angular-clipboard',
    'ngAnimate',
    'checklist-model',
    'tmh.dynamicLocale',
    'ngNotify',
    'ui.tree',
    'ngPasswordGenerator',
    'ui.select',
    'ngScrollable',
    'infinite-scroll'
]);

app.run([
    "$rootScope", "$state", "$stateParams", function($rootScope, $state, $stateParams) {
        
        $rootScope.$state = $state;
        $rootScope.currentUser = userInformation;
        $rootScope.version = version;
        $rootScope.isAdmin = ($rootScope.currentUser.admin !== undefined && $rootScope.currentUser.admin);

        return $rootScope.$stateParams = $stateParams;
    }
]);

(function() {
    app.constant("MY_GLOBAL_SETTINGS", {
        user: userInformation,
        token: userToken,
        templateUrl: "/angular/",
        languageBaseUrl: "/angular/i18n/",
        preferredLanguage: (typeof userInformation !== "undefined" && userInformation !== "") ? userInformation.language.id : "en",
        baseUrl: baseUrl
});
})();