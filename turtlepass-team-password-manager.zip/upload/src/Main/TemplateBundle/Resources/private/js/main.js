$( document ).ready(function() {
    $( ".sidebar-toggle" ).click(function() {
	  $( ".sidebar" ).toggle();
	});
});