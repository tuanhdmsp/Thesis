<?php

namespace Main\ApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MainApiBundle extends Bundle
{
}
