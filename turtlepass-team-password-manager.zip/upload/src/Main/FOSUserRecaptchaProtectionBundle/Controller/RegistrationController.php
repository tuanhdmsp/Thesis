<?php

namespace Main\FOSUserRecaptchaProtectionBundle\Controller;

use Main\AppBundle\Entity\Setting;
use Symfony\Component\HttpFoundation\RedirectResponse;
use UniqueLibs\FOSUserRecaptchaProtectionBundle\Controller\RegistrationController as BaseRegistrationController;

class RegistrationController extends BaseRegistrationController
{
    public function registerAction()
    {
        $settingManager = $this->container->get('main_app.services.setting_manager');

        if ($settingManager->getSetting(Setting::ID_ENABLE_REGISTRATION)->getValue() == '0') {
            return new RedirectResponse($this->container->get('router')->generate('fos_user_security_login'));
        }

        return parent::registerAction();
    }
}
