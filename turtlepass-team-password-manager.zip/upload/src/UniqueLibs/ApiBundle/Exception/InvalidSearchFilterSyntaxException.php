<?php

namespace UniqueLibs\ApiBundle\Exception;

class InvalidSearchFilterSyntaxException extends \Exception
{

}