<?php

namespace UniqueLibs\ApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UniqueLibsApiBundle extends Bundle
{
}
