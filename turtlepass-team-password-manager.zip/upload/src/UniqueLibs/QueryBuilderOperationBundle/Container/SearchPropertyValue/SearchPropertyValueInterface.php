<?php

namespace UniqueLibs\QueryBuilderOperationBundle\SearchPropertyValue;

interface SearchPropertyValueInterface
{
}
