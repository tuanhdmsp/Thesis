<?php

namespace UniqueLibs\QueryBuilderOperationBundle\Exception;

class InvalidSearchFilterSyntaxException extends \Exception
{
}
