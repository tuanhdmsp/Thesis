<?php

namespace UniqueLibs\QueryBuilderOperationBundle\Exception;

class UnexpectedException extends \Exception
{
}
