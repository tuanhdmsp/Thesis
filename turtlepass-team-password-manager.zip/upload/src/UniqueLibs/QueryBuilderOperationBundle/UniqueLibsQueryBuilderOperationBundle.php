<?php

namespace UniqueLibs\QueryBuilderOperationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UniqueLibsQueryBuilderOperationBundle extends Bundle
{
}
